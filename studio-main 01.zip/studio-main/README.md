# Firebase Studio

This is a NextJS starter in Firebase Studio.

Owner: DR.Mohsin Saleem

To get started, take a look at src/app/page.tsx.
